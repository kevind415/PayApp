# Getting Started with Create React App
- Make sure you have node installed: https://nodejs.org/en/download/
- Install vs code https://code.visualstudio.com/download

# Setup project
- `npm i` or `npm install` 
- Start dev server with `npm start`

# Routing
- https://reactrouter.com/web/guides/quick-start